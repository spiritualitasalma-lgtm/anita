<?php
session_start();
include "koneksi.php"; // opsional, kalau auth butuh cek DB

if (!isset($_SESSION['login'])) {
    header("Location: login.php");
    exit;
}
?>
