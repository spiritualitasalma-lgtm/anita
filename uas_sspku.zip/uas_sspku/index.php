<?php
include "auth.php";
include "koneksi.php";
?>

<!DOCTYPE html>
<html>
<head>
    <title>E-Commerce Sederhana</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<div class="container mt-4">
    <h2>Daftar Produk</h2>
    <a href="tambah.php" class="btn btn-primary mb-3">Tambah Produk</a>

    <table class="table table-bordered align-middle">
        <thead class="table-light">
            <tr>
                <th width="50">No</th>
                <th>Produk</th>
                <th width="150">Harga</th>
                <th>Deskripsi</th>
                <th width="150">Aksi</th>
            </tr>
        </thead>
        <tbody>
        <?php
        $no = 1;
        $data = mysqli_query($koneksi, "SELECT * FROM produk");

        while ($row = mysqli_fetch_assoc($data)) {
            $id_produk = $row['id'];
        ?>
            <tr>
                <td><?= $no++; ?></td>

                <!-- Gambar + Nama -->
                <td>
                    <div class="d-flex align-items-center gap-3">

                        <!-- LIST GAMBAR -->
                        <div class="d-flex gap-1 flex-wrap">
                            <?php
                            $gambar = mysqli_query(
                                $koneksi,
                                "SELECT * FROM produk_gambar WHERE produk_id='$id_produk'"
                            );

                            if (mysqli_num_rows($gambar) > 0) {
                                while ($g = mysqli_fetch_assoc($gambar)) {
                            ?>
                                    <img 
                                        src="gambar/<?= htmlspecialchars($g['gambar']); ?>"
                                        width="45"
                                        height="45"
                                        style="object-fit:cover;border-radius:6px;"
                                    >
                            <?php
                                }
                            } else {
                            ?>
                                <img 
                                    src="gambar/no-image.webp"
                                    width="45"
                                    height="45"
                                    style="object-fit:cover;border-radius:6px;"
                                >
                            <?php } ?>
                        </div>

                        <strong><?= htmlspecialchars($row['name']); ?></strong>
                    </div>
                </td>

                <td>Rp <?= number_format($row['price'], 0, ',', '.'); ?></td>
                <td><?= htmlspecialchars($row['description']); ?></td>

                <td>
                    <a href="edit.php?id=<?= $row['id']; ?>" class="btn btn-warning btn-sm">Edit</a>

                    <!-- Tombol Hapus -->
                    <button 
                        class="btn btn-danger btn-sm"
                        data-bs-toggle="modal"
                        data-bs-target="#hapusModal<?= $row['id']; ?>">
                        Hapus
                    </button>
                </td>
            </tr>

            <!-- MODAL HAPUS -->
            <div class="modal fade" id="hapusModal<?= $row['id']; ?>" tabindex="-1">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content">

                        <div class="modal-header">
                            <h5 class="modal-title">Konfirmasi Hapus</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>

                        <div class="modal-body">
                            Yakin ingin menghapus produk  
                            <strong><?= htmlspecialchars($row['name']); ?></strong>?
                        </div>

                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                                Batal
                            </button>
                            <a href="hapus.php?id=<?= $row['id']; ?>" class="btn btn-danger">
                                Hapus
                            </a>
                        </div>

                    </div>
                </div>
            </div>
            <!-- END MODAL -->

        <?php } ?>
        </tbody>
    </table>
</div>

<!-- Bootstrap JS (WAJIB) -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
