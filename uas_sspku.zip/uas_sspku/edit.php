<?php
include "auth.php";
include "koneksi.php";

if (!isset($_GET['id'])) {
    header("Location: index.php");
    exit;
}

$id = $_GET['id'];
$data = mysqli_query($koneksi, "SELECT * FROM produk WHERE id='$id'");
$row = mysqli_fetch_assoc($data);

if (!$row) {
    echo "Data tidak ditemukan";
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Produk</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<div class="container mt-4">
    <h2>Edit Produk</h2>

    <form method="post">
        <div class="mb-3">
            <label>Nama Produk</label>
            <input type="text" name="name" value="<?= $row['name']; ?>" class="form-control" required>
        </div>

        <div class="mb-3">
            <label>Harga</label>
            <input type="number" name="price" value="<?= $row['price']; ?>" class="form-control" required>
        </div>

        <div class="mb-3">
            <label>Deskripsi</label>
            <textarea name="description" class="form-control" required><?= $row['description']; ?></textarea>
        </div>

        <button type="submit" name="update" class="btn btn-success">Update</button>
        <a href="index.php" class="btn btn-secondary">Kembali</a>
    </form>

    <?php
    if (isset($_POST['update'])) {
        mysqli_query($koneksi, "UPDATE produk SET
            name='$_POST[name]',
            price='$_POST[price]',
            description='$_POST[description]'
            WHERE id='$id'
        ");

        header("Location: index.php");
        exit;
    }
    ?>
</div>

</body>
</html>
