<?php
$server   = "NAMA_SERVER_SQL_HOSTING";
$username = "USERNAME_DATABASE";
$password = "PASSWORD_DATABASE";
$database = "NAMA_DATABASE_HOSTING";

$koneksi = mysqli_connect($server, $username, $password, $database);

if (!$koneksi) {
    die("Koneksi database gagal");
}
?>
