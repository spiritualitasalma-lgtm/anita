CREATE DATABASE IF NOT EXISTS uas_sspku;
USE uas_sspku;

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50),
    password VARCHAR(255)
);

CREATE TABLE produk (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama VARCHAR(200),
    harga INT,
    deskripsi TEXT,
    gambar VARCHAR(100)
);
