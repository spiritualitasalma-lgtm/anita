-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 22, 2026 at 07:36 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `uas_sspku`
--

-- --------------------------------------------------------

--
-- Table structure for table `produk`
--

CREATE TABLE IF NOT EXISTS `produk` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `price` int(11) NOT NULL,
  `description` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `produk`
--

INSERT INTO `produk` (`id`, `name`, `price`, `description`) VALUES
(1, 'Laptop ABC', 7500000, 'Laptop 14 inch, Intel i5, RAM 8GB, SSD 256GB'),
(2, 'Headphone Pro', 1200000, 'Wireless Bluetooth, Noise Cancelling'),
(3, 'Smartwatch S1', 850000, 'Smartwatch dengan heart rate monitor dan GPS'),
(4, 'Tas Ransel Premium', 450000, 'Ransel anti air, kapasitas 25L, banyak kantong'),
(5, 'Sepatu Sport Ultra', 650000, 'Sneakers ringan untuk olahraga dan jalan sehari-hari'),
(6, 'Kamera Mirrorless M100', 5500000, 'Mirrorless 24MP, Video 4K, Lensa kit 15-45mm'),
(7, 'Speaker Bluetooth X10', 400000, 'Portable speaker dengan bass kuat, waterproof'),
(8, 'Baju Casual Pria', 200000, 'T-shirt cotton, nyaman dipakai sehari-hari'),
(9, 'Kacamata Hitam Trendy', 150000, 'Kacamata UV400, frame stylish'),
(10, 'Smartphone XYZ', 350000, 'Smartphone 6.5 inch, RAM 6GB, Kamera 48MP');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
