-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 22, 2026 at 07:42 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `uas_sspku`
--

-- --------------------------------------------------------

--
-- Table structure for table `produk_gambar`
--

CREATE TABLE IF NOT EXISTS `produk_gambar` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `produk_id` int(11) NOT NULL,
  `gambar` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `produk_gambar`
--

INSERT INTO `produk_gambar` (`id`, `produk_id`, `gambar`) VALUES
(1, 1, 'laptop_abc.webp'),
(2, 2, 'Headphone_Pro.webp'),
(3, 3, 'Smartwatch_S1.webp'),
(4, 4, 'Tas_Ransel.webp'),
(5, 5, 'Sepatu_Sport.webp'),
(6, 6, 'Kamera_Mirrorless_M100.webp'),
(7, 7, 'Speaker_Bluetooth_X10.webp'),
(8, 8, 'Baju_Casual_Pria.webp'),
(9, 9, 'Kacamata_Hitam.webp'),
(10, 10, 'Smartphone_XYZ.webp');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
